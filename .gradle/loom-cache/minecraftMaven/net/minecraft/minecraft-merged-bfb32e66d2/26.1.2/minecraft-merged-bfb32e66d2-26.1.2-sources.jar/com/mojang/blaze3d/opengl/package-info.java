@NullMarked
@Environment(EnvType.CLIENT)
package com.mojang.blaze3d.opengl;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.NullMarked;
